import javax.ws.rs.PathParam;

public class Calculate1 {

	public int calculate1(int var1, int var2 ) {
		
		int calories;
		calories = (int) (var1 * 0.75 * var2);
		
		return calories;
	}

}