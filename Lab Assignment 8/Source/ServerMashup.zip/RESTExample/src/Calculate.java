import javax.ws.rs.PathParam;

public class Calculate {

	public int calculate(int var1) {
		
		int weightinkg;
		weightinkg = (int) (var1 * 0.4535);
		
		return weightinkg;
	}

}