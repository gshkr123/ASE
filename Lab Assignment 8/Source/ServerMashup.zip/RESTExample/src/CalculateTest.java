import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculateTest {

	Calculate calculation = new Calculate();
	int sum = calculation.calculate(100);
	int testSum = 45;

	@Test
	public void testSum() {
		System.out.println("@Test Weightinkg(): " + sum + " = " + testSum);
		assertEquals(sum, testSum);
	}

}