import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculateTest1 {

	Calculate1 calculation = new Calculate1();
	int sum = calculation.calculate1(8,100);
	int testSum = 600;

	@Test
	public void testSum() {
		System.out.println("@Test Weightinkg(): " + sum + " = " + testSum);
		assertEquals(sum, testSum);
	}

}