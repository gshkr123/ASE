/**
 * @author ry6d3
 *
 */
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import org.json.JSONException;
import org.json.JSONObject;
 
//@Path("/ftocservice")
//public class FtoCService {
// 
//	  @GET
//	  @Produces("application/json")
//	  public Response convertFtoC() throws JSONException {
// 
//		JSONObject jsonObject = new JSONObject();
//		Double fahrenheit = 98.24;
//		Double celsius;
//		celsius = (fahrenheit - 32)*5/9; 
//		jsonObject.put("F Value", fahrenheit); 
//		jsonObject.put("C Value", celsius);
// 
//		String result = "@Produces(\"application/json\") Output: \n\nF to C Converter Output: \n\n" + jsonObject;
//		return Response.status(200).entity(result).build();
//	  }
 
@Path("/caloriesburned")
public class FtoCService {

	@GET
	@Path("/calories/{weight}/{miles}")
	@Produces("application/xml")
	public String convertCtoFfromInput(@PathParam("weight") Double weight,@PathParam("miles") Double miles) {
		Double calories;
		calories = (weight * 0.75 * miles);
 
		String result = "@Produces(\"application/xml\") Output: \n\nCalories Burned Output: \n\n" + calories;
		return "<caloriesburned>" + "<calories>" + calories + "</calories>" + "<result>" + result + "</result>" + "</caloriesburned>";
	}
}