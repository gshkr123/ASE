/**
 * @author ry6d3
 *
 */
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
 
@Path("/ctofservice")
public class CtoFService {

	@GET
	@Path("/calories/{weight}")
	@Produces("application/xml")
	public String convertCtoFfromInput(@PathParam("weight") Double weight) {
		Double weightinkg;
		weightinkg = (weight * 0.4535);
 
		String result = "@Produces(\"application/xml\") Output: \n\nWeight To Kg: \n\n" + weightinkg;
		return "<weightconversion>" + "<weight>" + weightinkg + "</weight>" + "<result>" + result + "</result>" + "</weightconversion>";
	}
}